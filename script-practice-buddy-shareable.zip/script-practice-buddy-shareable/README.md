
# Script Practice Buddy — Shareable Package

This folder is ready for **Netlify Drop** or **GitHub Pages**. It includes:
- `index.html` — your app (with a small loader that seeds shared data)
- `scripts.json` — the shared starter set your viewers will see on first visit

## Fastest: Netlify Drop
1. Go to https://app.netlify.com/drop
2. Drag the **entire folder** in.
3. You’ll get a public URL instantly.

## Durable: GitHub Pages
1. Create a new repo → upload both files (or drag the whole folder).
2. Rename repo `script-practice-buddy` (optional).
3. Settings → **Pages** → Source: `main` branch.
4. Your site will be available at `https://<username>.github.io/<reponame>/`

## Dropbox or any static host
- Upload both files side-by-side.
- Use the **direct** link to `index.html` or the folder.
- `scripts.json` must sit next to `index.html` so the app can fetch it.

## How the shared data works
- On first load, the app tries to fetch `scripts.json`. If found, it saves those Q/A pairs into the browser’s `localStorage` and marks them as preloaded.
- If `scripts.json` isn’t available (or fetch fails), it seeds **embedded defaults** instead.
- Each viewer can still import or edit their own library — that stays on their device.

## Update your shared set
Edit `scripts.json` and redeploy. New visitors will get the new set on first visit.

— Generated 2025-11-10T04:05:53
